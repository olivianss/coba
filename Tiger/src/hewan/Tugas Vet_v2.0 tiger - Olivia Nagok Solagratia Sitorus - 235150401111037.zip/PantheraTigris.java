package hewan;
public class PantheraTigris {

    String id;
    String colour;
    String name;
    int yearOfBirth;

    String eat(){
        return "Rau rau rau...";
    }
    
    String roar(){
        //System.out.println("Roarrrr");
        return "Roarrr";


    
}
}
